// lib/screens/game_setup_screen.dart

import 'package:flutter/material.dart';
import 'package:octominia/models/game.dart';
import 'package:octominia/models/faction.dart';
import 'package:octominia/database/database_helper.dart';

class GameSetupScreen extends StatefulWidget {
  final Game game;
  final Function(Game) onUpdate;

  const GameSetupScreen({super.key, required this.game, required this.onUpdate});

  @override
  State<GameSetupScreen> createState() => _GameSetupScreenState();
}

class _GameSetupScreenState extends State<GameSetupScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _myPlayerNameController = TextEditingController();
  final TextEditingController _opponentPlayerNameController = TextEditingController();

  List<Faction> _factions = [];
  Faction? _mySelectedFaction;
  Faction? _opponentSelectedFaction;
  bool _isLoadingFactions = true;

  // Variables pour les sliders
  int _myCurrentDrops = 0;
  int _opponentCurrentDrops = 0;

  @override
  void initState() {
    super.initState();
    _myPlayerNameController.text = widget.game.myPlayerName;
    _opponentPlayerNameController.text = widget.game.opponentPlayerName;

    _loadFactions();

    // Initialisation des sliders
    _myCurrentDrops = widget.game.myDrops;
    _opponentCurrentDrops = widget.game.opponentDrops;
  }

  @override
  void dispose() {
    _myPlayerNameController.dispose();
    _opponentPlayerNameController.dispose();
    super.dispose();
  }

  Future<void> _loadFactions() async {
    setState(() {
      _isLoadingFactions = true;
    });
    try {
      final dbHelper = DatabaseHelper();
      _factions = await dbHelper.getFactions();

      // Initialiser les factions sélectionnées si des noms de factions sont déjà définis dans le jeu
      if (widget.game.myFactionName.isNotEmpty) {
        _mySelectedFaction = _factions.firstWhere(
          (faction) => faction.name == widget.game.myFactionName,
          orElse: () => Faction(
            uuid: '', // Fournir des valeurs par défaut si non trouvées
            name: widget.game.myFactionName,
            orderUuid: '',
            orderId: 0,
            description: '',
            imageUrl: null,
          ),
        );
      }
      if (widget.game.opponentFactionName.isNotEmpty) {
        _opponentSelectedFaction = _factions.firstWhere(
          (faction) => faction.name == widget.game.opponentFactionName,
          orElse: () => Faction(
            uuid: '', // Fournir des valeurs par défaut si non trouvées
            name: widget.game.opponentFactionName,
            orderUuid: '',
            orderId: 0,
            description: '',
            imageUrl: null,
          ),
        );
      }
    } catch (e) {
      print('Error loading factions: $e');
      // Gérer l'erreur, peut-être afficher un message à l'utilisateur
    } finally {
      setState(() {
        _isLoadingFactions = false;
      });
    }
  }

  void _updateGame() {
    widget.onUpdate(widget.game.copyWith(
      myPlayerName: _myPlayerNameController.text,
      myFactionName: _mySelectedFaction?.name ?? '', // Utilisation de l'opérateur null-aware
      myFactionImageUrl: _mySelectedFaction?.imageUrl, // Utilisation de l'opérateur null-aware
      myDrops: _myCurrentDrops,
      myAuxiliaryUnits: widget.game.myAuxiliaryUnits, // Garder comme tel, le checkbox met à jour directement
      opponentPlayerName: _opponentPlayerNameController.text,
      opponentFactionName: _opponentSelectedFaction?.name ?? '', // Utilisation de l'opérateur null-aware
      opponentFactionImageUrl: _opponentSelectedFaction?.imageUrl, // Utilisation de l'opérateur null-aware
      opponentDrops: _opponentCurrentDrops,
      opponentAuxiliaryUnits: widget.game.opponentAuxiliaryUnits, // Garder comme tel, le checkbox met à jour directement
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoadingFactions) {
      return const Center(child: CircularProgressIndicator());
    }

    return SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Section de mon joueur
                Text(
                  'Mon Joueur',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _myPlayerNameController,
                  decoration: InputDecoration(
                    labelText: 'Nom du Joueur',
                    border: const OutlineInputBorder(),
                    labelStyle: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                  ),
                  style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Veuillez entrer le nom de votre joueur';
                    }
                    return null;
                  },
                  onChanged: (value) => _updateGame(),
                ),
                const SizedBox(height: 16.0),
                DropdownButtonFormField<Faction>(
                  decoration: InputDecoration(
                    labelText: 'Ma Faction',
                    border: const OutlineInputBorder(),
                    labelStyle: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                  ),
                  value: _mySelectedFaction,
                  items: _factions.map<DropdownMenuItem<Faction>>((Faction faction) {
                    return DropdownMenuItem<Faction>(
                      value: faction,
                      child: Text(faction.name, style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color)),
                    );
                  }).toList(),
                  onChanged: (Faction? newValue) {
                    setState(() {
                      _mySelectedFaction = newValue;
                      _updateGame();
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Veuillez sélectionner une faction';
                    }
                    return null;
                  },
                  dropdownColor: Theme.of(context).canvasColor,
                ),
                const SizedBox(height: 16.0),
                Text(
                  'Mes Drops: $_myCurrentDrops',
                  style: TextStyle(fontSize: 16, color: Theme.of(context).textTheme.bodyLarge?.color),
                ),
                Slider(
                  value: _myCurrentDrops.toDouble(),
                  min: 0,
                  max: 5,
                  divisions: 5,
                  label: _myCurrentDrops.round().toString(),
                  onChanged: (double value) {
                    setState(() {
                      _myCurrentDrops = value.round();
                      _updateGame();
                    });
                  },
                  activeColor: Theme.of(context).primaryColor,
                  inactiveColor: Theme.of(context).primaryColor.withOpacity(0.3),
                ),
                Row(
                  children: [
                    Checkbox(
                      value: widget.game.myAuxiliaryUnits,
                      onChanged: (bool? newValue) {
                        setState(() {
                          widget.onUpdate(widget.game.copyWith(myAuxiliaryUnits: newValue));
                        });
                      },
                      checkColor: Colors.white,
                      activeColor: Theme.of(context).primaryColor,
                    ),
                    Text(
                      'J\'ai des unités auxiliaires',
                      style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                    ),
                  ],
                ),
                const SizedBox(height: 24.0),

                // Section de l'adversaire
                Text(
                  'Adversaire',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16.0),
                TextFormField(
                  controller: _opponentPlayerNameController,
                  decoration: InputDecoration(
                    labelText: 'Nom du Joueur Adversaire',
                    border: const OutlineInputBorder(),
                    labelStyle: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                  ),
                  style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Veuillez entrer le nom du joueur adversaire';
                    }
                    return null;
                  },
                  onChanged: (value) => _updateGame(),
                ),
                const SizedBox(height: 16.0),
                DropdownButtonFormField<Faction>(
                  decoration: InputDecoration(
                    labelText: 'Faction Adversaire',
                    border: const OutlineInputBorder(),
                    labelStyle: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                  ),
                  value: _opponentSelectedFaction,
                  items: _factions.map<DropdownMenuItem<Faction>>((Faction faction) {
                    return DropdownMenuItem<Faction>(
                      value: faction,
                      child: Text(faction.name, style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color)),
                    );
                  }).toList(),
                  onChanged: (Faction? newValue) {
                    setState(() {
                      _opponentSelectedFaction = newValue;
                      _updateGame();
                    });
                  },
                  validator: (value) {
                    if (value == null) {
                      return 'Veuillez sélectionner une faction pour l\'adversaire';
                    }
                    return null;
                  },
                  dropdownColor: Theme.of(context).canvasColor,
                ),
                const SizedBox(height: 16.0),
                Text(
                  'Drops Adversaire: $_opponentCurrentDrops',
                  style: TextStyle(fontSize: 16, color: Theme.of(context).textTheme.bodyLarge?.color),
                ),
                Slider(
                  value: _opponentCurrentDrops.toDouble(),
                  min: 0,
                  max: 5,
                  divisions: 4,
                  label: _opponentCurrentDrops.round().toString(),
                  onChanged: (double value) {
                    setState(() {
                      _opponentCurrentDrops = value.round();
                      _updateGame();
                    });
                  },
                  activeColor: Theme.of(context).colorScheme.secondary,
                  inactiveColor: Theme.of(context).colorScheme.secondary.withOpacity(0.3),
                ),
                Row(
                  children: [
                    Checkbox(
                      value: widget.game.opponentAuxiliaryUnits,
                      onChanged: (bool? newValue) {
                        setState(() {
                          widget.onUpdate(widget.game.copyWith(opponentAuxiliaryUnits: newValue));
                        });
                      },
                      checkColor: Colors.black,
                      activeColor: Theme.of(context).colorScheme.secondary,
                    ),
                    Text(
                      'L\'adversaire a des unités auxiliaires',
                      style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color),
                    ),
                  ],
                ),
                const SizedBox(height: 24.0),
              ],
            ),
          ),
        );
  }
}