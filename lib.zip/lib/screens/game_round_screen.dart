// lib/screens/game_round_screen.dart

import 'package:flutter/material.dart';
import 'package:octominia/models/game.dart';
import 'package:octominia/models/round.dart';

class GameRoundScreen extends StatefulWidget {
  final int roundNumber;
  final Game game;
  final Function(Round) onUpdateRound;

  const GameRoundScreen({
    super.key,
    required this.roundNumber,
    required this.game,
    required this.onUpdateRound,
  });

  @override
  State<GameRoundScreen> createState() => _GameRoundScreenState();
}

class _GameRoundScreenState extends State<GameRoundScreen> {
  late Round _currentRound;
  late String _myPlayerName;
  late String _opponentPlayerName;

  @override
  void initState() {
    super.initState();
    _myPlayerName = widget.game.myPlayerName;
    _opponentPlayerName = widget.game.opponentPlayerName;

    // Assurez-vous que _currentRound est une COPIE pour éviter les modifications directes
    // de l'objet Game parent si on ne veut pas qu'elles soient persistantes avant onUpdateRound.
    // Cependant, pour l'approche StatefulWidget, modifier _currentRound localement
    // puis appeler onUpdateRound pour propager est une bonne pratique.
    // Le Game contient déjà 5 rounds initialisés dans AddGameScreen, donc nous les trouvons
    _currentRound = widget.game.rounds.firstWhere(
      (round) => round.roundNumber == widget.roundNumber,
      orElse: () => Round(
        roundNumber: widget.roundNumber,
        myScore: 0,
        opponentScore: 0,
        priorityPlayerId: null,
        myQuest1_1Completed: false,
        myQuest1_2Completed: false,
        myQuest1_3Completed: false,
        myQuest2_1Completed: false,
        myQuest2_2Completed: false,
        myQuest2_3Completed: false,
        opponentQuest1_1Completed: false,
        opponentQuest1_2Completed: false,
        opponentQuest1_3Completed: false,
        opponentQuest2_1Completed: false,
        opponentQuest2_2Completed: false,
        opponentQuest2_3Completed: false,
      ),
    );

    // Set default priority for the current round to 'me' if not already set
    if (_currentRound.priorityPlayerId == null) {
      _currentRound = _currentRound.copyWith(priorityPlayerId: 'me');
      widget.onUpdateRound(_currentRound);
    }
  }

  void _updateRound() {
    widget.onUpdateRound(_currentRound);
  }

  // --- NOUVELLES FONCTIONS D'AIDE POUR LES ÉLÉMENTS DE MISE EN PAGE CONCIS ---

  Widget _buildPrioritySelection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Qui a la priorité pour ce tour ?',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodyLarge?.color),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    _currentRound = _currentRound.copyWith(priorityPlayerId: 'me');
                    _updateRound();
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _currentRound.priorityPlayerId == 'me'
                      ? Theme.of(context).primaryColor
                      : Theme.of(context).disabledColor,
                  foregroundColor: _currentRound.priorityPlayerId == 'me' ? Colors.white : Colors.black,
                ),
                child: Text(_myPlayerName),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    _currentRound = _currentRound.copyWith(priorityPlayerId: 'opponent');
                    _updateRound();
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _currentRound.priorityPlayerId == 'opponent'
                      ? Theme.of(context).colorScheme.secondary
                      : Theme.of(context).disabledColor,
                  foregroundColor: _currentRound.priorityPlayerId == 'opponent' ? Colors.black : Colors.white,
                ),
                child: Text(_opponentPlayerName),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildPrimaryScoreSelection(BuildContext context, String playerName, int currentScore, bool isMyPlayer) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Score Primaire de $playerName (0-10)',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodyLarge?.color),
        ),
        Slider(
          value: currentScore.toDouble(),
          min: 0,
          max: 10,
          divisions: 10,
          label: currentScore.toString(),
          onChanged: (double value) {
            setState(() {
              if (isMyPlayer) {
                _currentRound = _currentRound.copyWith(myScore: value.toInt());
              } else {
                _currentRound = _currentRound.copyWith(opponentScore: value.toInt());
              }
              _updateRound();
            });
          },
          activeColor: isMyPlayer ? Theme.of(context).primaryColor : Theme.of(context).colorScheme.secondary,
          inactiveColor: (isMyPlayer ? Theme.of(context).primaryColor : Theme.of(context).colorScheme.secondary).withOpacity(0.3),
        ),
      ],
    );
  }

  Widget _buildQuestSection(BuildContext context, String playerName, bool isMyPlayer) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Objectifs de $playerName',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.bodyLarge?.color),
        ),
        const SizedBox(height: 8),
        _buildQuestCheckbox(context, 'Quête 1.1', isMyPlayer ? _currentRound.myQuest1_1Completed : _currentRound.opponentQuest1_1Completed, (newValue) {
          setState(() {
            _currentRound = isMyPlayer ? _currentRound.copyWith(myQuest1_1Completed: newValue) : _currentRound.copyWith(opponentQuest1_1Completed: newValue);
            _updateRound();
          });
        }, isMyPlayer),
        _buildQuestCheckbox(context, 'Quête 1.2', isMyPlayer ? _currentRound.myQuest1_2Completed : _currentRound.opponentQuest1_2Completed, (newValue) {
          setState(() {
            _currentRound = isMyPlayer ? _currentRound.copyWith(myQuest1_2Completed: newValue) : _currentRound.copyWith(opponentQuest1_2Completed: newValue);
            _updateRound();
          });
        }, isMyPlayer),
        _buildQuestCheckbox(context, 'Quête 1.3', isMyPlayer ? _currentRound.myQuest1_3Completed : _currentRound.opponentQuest1_3Completed, (newValue) {
          setState(() {
            _currentRound = isMyPlayer ? _currentRound.copyWith(myQuest1_3Completed: newValue) : _currentRound.copyWith(opponentQuest1_3Completed: newValue);
            _updateRound();
          });
        }, isMyPlayer),
        _buildQuestCheckbox(context, 'Quête 2.1', isMyPlayer ? _currentRound.myQuest2_1Completed : _currentRound.opponentQuest2_1Completed, (newValue) {
          setState(() {
            _currentRound = isMyPlayer ? _currentRound.copyWith(myQuest2_1Completed: newValue) : _currentRound.copyWith(opponentQuest2_1Completed: newValue);
            _updateRound();
          });
        }, isMyPlayer),
        _buildQuestCheckbox(context, 'Quête 2.2', isMyPlayer ? _currentRound.myQuest2_2Completed : _currentRound.opponentQuest2_2Completed, (newValue) {
          setState(() {
            _currentRound = isMyPlayer ? _currentRound.copyWith(myQuest2_2Completed: newValue) : _currentRound.copyWith(opponentQuest2_2Completed: newValue);
            _updateRound();
          });
        }, isMyPlayer),
        _buildQuestCheckbox(context, 'Quête 2.3', isMyPlayer ? _currentRound.myQuest2_3Completed : _currentRound.opponentQuest2_3Completed, (newValue) {
          setState(() {
            _currentRound = isMyPlayer ? _currentRound.copyWith(myQuest2_3Completed: newValue) : _currentRound.copyWith(opponentQuest2_3Completed: newValue);
            _updateRound();
          });
        }, isMyPlayer),
      ],
    );
  }

  Widget _buildQuestCheckbox(BuildContext context, String title, bool value, ValueChanged<bool?> onChanged, bool isMyPlayer) {
    return Row(
      children: [
        Checkbox(
          value: value,
          onChanged: onChanged,
          checkColor: isMyPlayer ? Colors.white : Colors.black,
          activeColor: isMyPlayer ? Theme.of(context).primaryColor : Theme.of(context).colorScheme.secondary,
        ),
        Text(title, style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // Calcul des scores totaux à afficher en haut de page pour le contexte
    int myOverallTotalScore = widget.game.myScore;
    int opponentOverallTotalScore = widget.game.opponentScore;

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Align(
              alignment: Alignment.center,
              child: Text(
                'Tour ${widget.roundNumber}',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Theme.of(context).textTheme.headlineSmall?.color),
              ),
            ),
            const SizedBox(height: 10),
            // Aperçu du Score Total Actuel
            Align(
              alignment: Alignment.center,
              child: Text(
                'Score Actuel: $_myPlayerName $myOverallTotalScore - $_opponentPlayerName $opponentOverallTotalScore',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blueAccent),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),

            _buildPrioritySelection(context),
            const SizedBox(height: 20),

            // Section pour mon joueur
            _buildPrimaryScoreSelection(context, _myPlayerName, _currentRound.myScore, true),
            _buildQuestSection(context, _myPlayerName, true),

            const SizedBox(height: 20), // Espace entre les sections joueur

            // Section pour l'adversaire
            _buildPrimaryScoreSelection(context, _opponentPlayerName, _currentRound.opponentScore, false),
            _buildQuestSection(context, _opponentPlayerName, false),
          ],
        ),
      ),
    );
  }
}